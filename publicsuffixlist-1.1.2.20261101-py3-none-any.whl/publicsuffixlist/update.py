#
# Copyright 2014 ko-zu <causeless@gmail.com>
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
import calendar
import os
from email.utils import parsedate

from publicsuffixlist import PSLFILE, PSLURL, PublicSuffixList


def updatePSL(psl_file: str = PSLFILE) -> None:
    """Updates a local copy of PSL file

    :param psl_file: path for the file to store the list. Default: PSLFILE
    """
    print("This is a script to download the latest PSL file.")
    print("Do not run this repeatedly more than once per day.")

    try:
        import requests
    except ImportError:
        raise Exception("Please install python-requests http(s) library. $ sudo pip install requests")

    r = requests.get(PSLURL)
    if r.status_code != requests.codes.ok or len(r.content) == 0:
        raise Exception("Could not download PSL from " + PSLURL)

    lastmod = r.headers.get("last-modified", None)
    with open(psl_file + ".swp", "wb") as f:
        f.write(r.content)

    with open(psl_file + ".swp", "rb") as f:
        # Constructing the object validates that the downloaded file parses.
        _psl = PublicSuffixList(f)

    try:
        os.replace(psl_file + ".swp", psl_file)
    except AttributeError:
        # will not work on python2 on Win.
        os.rename(psl_file + ".swp", psl_file)

    if lastmod:
        # parsedate returns None for a malformed Last-Modified header.
        parsed = parsedate(lastmod)
        if parsed is not None:
            t = calendar.timegm(parsed)
            os.utime(psl_file, (t, t))

    print("PSL updated")
    if lastmod:
        print("last-modified: " + lastmod)


if __name__ == "__main__":
    updatePSL()
